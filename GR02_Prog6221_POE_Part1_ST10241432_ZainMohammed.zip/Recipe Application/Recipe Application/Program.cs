﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recipe_Application
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Ingredients ing = new Ingredients();    //Create an object of the Ingrediants class called ingrediants
            ing.Menu();
        }
    }
}
