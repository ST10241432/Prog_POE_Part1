﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recipe_Application
{
    internal class Ingredients
    {
        
        string[] name;      //creating an array for the name of the ingredient
        double []quantity;      //creating an array for quantity of the ingredient
        string []unitOfMeasurement;     //creating an array for the unit of meaesurements
        string[] steps;     //creating an array for the steps
        double[] originalQuantity;      //create an array to retain original quantity values


        public void GetRecipeInput()    //Method to get user input for the ingredients of the recipe
        {
            int noOfIngredients;
            Console.WriteLine("Enter the amount of Ingredients used in the recipe");
            try
            {
                noOfIngredients = Convert.ToInt16(Console.ReadLine());
            }
            catch
            {
                bool isValid = false;
                do
                {
                    Console.WriteLine("Enter a numerical value for the number of ingredients");
                    if (isValid = int.TryParse(Console.ReadLine(),out noOfIngredients))
                    {
                        break;
                    }
                } while(!isValid);
            }
            /*
                providing the arrays with a length
             */
            name = new string[noOfIngredients];             
            quantity = new double[noOfIngredients];
            unitOfMeasurement = new string[noOfIngredients];
            originalQuantity = new double[quantity.Length];

            for (int i=0;i<noOfIngredients;i++)     //for loop to prompt the user for input
            {
                Console.WriteLine("Enter the name of the ingredient {0}",i+1);
                name[i] = Console.ReadLine();

                Console.WriteLine("Enter the unit of measuremnt being used for {0}", name[i]);
                unitOfMeasurement[i] = Console.ReadLine();
                try
                {
                    Console.WriteLine("Enter the quantity of {0} being used", name[i]);
                    quantity[i] = Convert.ToInt16(Console.ReadLine());
                }
                catch
                {
                    Console.WriteLine("Enter a numerical value");
                    bool isValid = false;
                    do
                    {
                        Console.WriteLine("Enter the quantity of {0} being used", name[i]);
                        if (isValid = double.TryParse(Console.ReadLine(), out quantity[i]))
                        {
                            break;
                        }
                    } while (!isValid);
                }

            }    
            for (int i = 0; i < quantity.Length; i++)       //for loop to copy the data from quantity to orignalquantity
            {
                originalQuantity[i] = quantity[i];
            }
        }
        public void GetStepsInput()     //method to get the the user input for the steps of the recipe
        {
            Console.WriteLine("Enter the number of steps that is going to be followed in this recipe");
            int stepsRecipe = Convert.ToInt16(Console.ReadLine());
            steps = new string[stepsRecipe];
            for (int i = 0; i < stepsRecipe; i++)
            {
                Console.WriteLine("Enter the details for step {0}", i+1 );
                steps[i] = Console.ReadLine();
            }
        }
        public void DisplayRecipe()     //method to display the recipe details; details being the ingredient description and steps
        {
            try
            {
                for (int i = 0; i < name.Length; i++)
                {
                    Console.WriteLine();
                    Console.Write(name[i] +" "+ quantity[i] + unitOfMeasurement[i]);
                }
            }
            catch(NullReferenceException)
            {
                Console.WriteLine("No ingredient details were entered");
            }
            try
            {
                for (int i = 0; i < steps.Length; i++)
                {
                    Console.WriteLine() ;
                    Console.Write("step {0}", i + 1 + " " + steps[i]);
                }
            }
            catch (NullReferenceException)
            {
                Console.WriteLine("No steps entered for this recipe");
            }

        }
        public void ScaleRecipe()       //method to scale the quantities of the ingredients according to what the user desires
        {
            int scale;
            
            Console.WriteLine("Select the amount you wish to scale the quantities by:");
            Console.WriteLine("[1] 0.5 \t [2] (double) \t [3] (triple) \t[4] (return to menu)\t [5] reset to default values");
            bool isValid = false;
            try
            {
                scale = Convert.ToInt16(Console.ReadLine());
            }
            catch
            {
                Console.WriteLine("Enter a numerical value");
                do
                {
                    Console.WriteLine("Select the amount you wish to scale the quantities by:");
                    Console.WriteLine("[1] 0.5 \t [2] (double) \t [3] (triple) \t[4] (return to menu)\t [5] reset to default values");
                    if (isValid = int.TryParse(Console.ReadLine(), out scale))
                    {
                        break;
                    }
                } while (!isValid);
            }


            try
            {
                if (scale == 1)
                {
                    for (int i = 0; i < quantity.Length; i++)
                    {
                        quantity[i] = quantity[i] * 0.5;
                    }
                }
                if (scale == 2)
                {
                    for (int i = 0; i < quantity.Length; i++)
                    {
                        quantity[i] = quantity[i] * 2;
                    }
                }
                if (scale == 3)
                {
                    for (int i = 0; i < quantity.Length; i++)
                    {
                        quantity[i] = quantity[i] * 3;
                    }
                }
                if (scale == 4)
                {
                    Menu();
                }
                if (scale == 5)
                {
                    for (int i = 0; i < quantity.Length; i++)
                    {
                        quantity[i] = originalQuantity[i];
                    }
                }
            }
            catch(System.NullReferenceException)
            {
                Console.WriteLine("There are no values entered for quanitites");
            }
        
        }
        public void ClearData()     //method to clear the data of the arrays
        {
            try
            {
                Array.Clear(quantity, 0, quantity.Length);
                Array.Clear(name, 0, name.Length);
                Array.Clear(steps, 0, steps.Length);
                Array.Clear(unitOfMeasurement, 0, unitOfMeasurement.Length);
                Console.WriteLine("The data has been cleared");

            }
            catch(System.ArgumentNullException )
            {
                Console.WriteLine("The data has been cleared");
            }
          
        }
        public void Menu()      //method that generates the menu 
        {
            int choice;
            Console.WriteLine("Choose operation:");
            Console.WriteLine("1. Enter recipe details");
            Console.WriteLine("2. Enter recipe steps");
            Console.WriteLine("3. Show recipe details");
            Console.WriteLine("4. Scale ingredient quantities");
            Console.WriteLine("5. Clear Data");
            Console.WriteLine("6. Exit Application");
            try
            {

                choice = int.Parse(Console.ReadLine());
                while (choice < 1 && choice > 6)                //Ensures the user enters a number available on the menu
                {
                    Console.WriteLine("Choose operation:");
                    Console.WriteLine("1. Enter recipe details");
                    Console.WriteLine("2. Enter recipe steps");
                    Console.WriteLine("3. Show recipe details");
                    Console.WriteLine("4. Scale ingredient quantities");
                    Console.WriteLine("5. Clear Data");
                    Console.WriteLine("6. Exit Application");
                    choice = int.Parse(Console.ReadLine());
                }
            }
            catch (Exception s)
            {
                bool isValid = false;

                do
                {
                    Console.WriteLine("Enter a numeric value between 1-6");
                    if (isValid = int.TryParse(Console.ReadLine(), out choice))
                    {
                        break;
                    }
                }
                while (!isValid);


            }
            do
            {
                switch (choice)
                {
                    case 1:
                        GetRecipeInput();
                        Menu();
                        break;
                    case 2:
                        GetStepsInput();
                        Menu();
                        break;
                    case 3:
                        DisplayRecipe();
                        Console.WriteLine();
                        Menu();
                        break;
                    case 4:
                        ScaleRecipe();
                        Menu();
                        break;
                    case 5:
                        ClearData();
                        Menu();
                        break;
                    case 6:
                        Console.WriteLine("You have decided to leave the application");
                        Environment.Exit(0);
                        break;

                }
            } while (choice != 6);
        }
    }

}


