
# Recipe Application

This project allows the user to enter and manupulate recipes.  The user is able to enter the the ingredients name, quantity and unit of measurement, as well as the steps that need to be followed in the recipe adn the ability to clear the data of the recipe.  Moreover the application can display the full recipe and steps ;and scale the quantity of ingredients by 0.5, 2 and 3 and revert the quantities back to the original value.

This application is intended for users who would like to digitilize their recipes and manipulate it.


## Install and Run

The version of visual studio used is visual studio 2022 and the project was compiled on .net framework 4.7.2.
## Features

- The data is not stored in memory.
- The application contains a menu to select what the use would like to do.
- The application includes an exit option in the menu.

